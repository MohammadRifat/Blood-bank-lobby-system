package services;
import repositories.*;
import entities.*;

import java.util.*;

public class UserService{

    User user = new User();
    List<User> userList=new ArrayList<User>();
    UserRepository urp=new UserRepository();
    
    public boolean addNewUser(User user){   //adding
        return urp.insertUserToDb(user);
    }
    public boolean editUser(User user){   //editing
        return urp.updateToDb(user);
    }
    public boolean removeUserByUsername(String username){  //removing
        return urp.removeFromDb(username);
    }

    public User getUserByUsername(String username){  //get username (unique)
        user = urp.getUserFromDb(username);
        return user;
    }
    public List<User> loadAllUser(){
        userList = urp.getAllUser();
        return userList;
    }

    public boolean getUserValidation(String username){  //validity check
        return urp.userValidation(username);
    }

    public boolean addUserAsAdmin(String username){  //admin add
        return urp.addAdmin(username);
    }

    public boolean removeUserAsAdmin(String username){  //admin remove
        return urp.removeAdmin(username);
    }

    public boolean updatePass(String username, String password){  //pass update
        return urp.updatePassFromDb(username,password);
    }

}