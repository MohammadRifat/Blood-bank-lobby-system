package services;
import repositories.*;
import entities.*;

import java.util.*;

public class RequestService{

    Request req;
    List<Request> reqList=new ArrayList<Request>();
    RequestRepository rrp=new RequestRepository();
    
    public boolean addNewRequest(Request req){  //add request
        return rrp.insertRequestToDb(req);
    }
    
    public boolean removeRequestById(int id){  //remove request
        return rrp.removeFromDb(id);
    }

    public Request getRequestById(int id){
        req = rrp.getRequestFromDb(id);
        return req;
    }
    public List<Request> loadAllRequest(){  //show all request
        reqList = rrp.getAllRequest();
        return reqList;
    }
    public boolean getIdValidation(int id){ //admin use
        return rrp.requestValidation(id);
    }


}