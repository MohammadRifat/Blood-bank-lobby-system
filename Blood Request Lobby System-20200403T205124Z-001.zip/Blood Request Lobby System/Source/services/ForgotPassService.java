package services;
import repositories.*;
import entities.*;

import java.util.*;

public class ForgotPassService{
    ForgotPass fp;
    ForgotPassRepository fps = new ForgotPassRepository();
    public boolean addForgotPass(ForgotPass fp){
        return fps.insertForgotPassToDb(fp);           //adding
    }

    public ForgotPass getForgotPassByUsername(String username){  //username getting
        fp = fps.getForgotPassFromDb(username);
        return fp;
    }

    public boolean removeForgotPass(String username){   //removing
        return fps.removeForgotPassFromDb(username);
    }


}