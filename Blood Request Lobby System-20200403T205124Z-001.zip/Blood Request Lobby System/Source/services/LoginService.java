package services;
import repositories.*;
import entities.*;

public class LoginService{
    UserRepository urp=new UserRepository();
    public LoginService(){

    }
    public boolean getValidation(String username,String password){   //username pass check
        return urp.loginValidation(username, password);
    }
}